<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="style.css">
        <style>
body{font-family:Georgia, serif;font-weight:bold;}

::placeholder {font-weight:normal;
font-family:Georgia, serif;color:black;
  text-align:center;
}
.form-center {
	display:flex;
	justify-content: center;
}
.logout
  {
    box-shadow: 0px 0px 18px 1px black;;
    padding: 20px;
    display: block;
    visibility: visible;
    text-decoration: none;
    text-align: center;
    color: white;
    float:left;
    margin-left: 600px;
    background-color: #006994;
    text-transform: uppercase;
    font-weight: bolder;
    font-size: 20px;
  }
.heading
  {
    font-family:Georgia, serif;
    font-weight:1000;
    font-size: 40px;
    text-align: center;
    color: white;
background-color:#006994;  }
          </style>
        
       </head>
<body>

<?php

session_start();

if($_SERVER['REQUEST_METHOD']=='POST')
{
    $id=$_SESSION['username'];
    $course=$_POST['course'];
    $n=$_POST['rno'];
    $q1=$_POST['q1'];
    $q2=$_POST['q2'];
    $q3=$_POST['q3'];
    $q4=$_POST['q4'];
    $q5=$_POST['q5'];
    $q6=$_POST['q6'];
    $q7=$_POST['q7'];
    $q8=$_POST['q8'];
    $q9=$_POST['q9'];
    $q10=$_POST['q10'];
    $q11=$_POST['q11'];
    $q12=$_POST['q12'];
    $q13=$_POST['q13'];
    $q14=$_POST['q14'];
    $q15=$_POST['q15'];
    $q16=$_POST['q16'];

    if($q1==NULL)
    {
        $q1=0;
    }
if($q2==NULL)
    {
        $q2=0;
    }
if($q3==NULL)
    {
        $q3=0;
    }
if($q4==NULL)
    {
        $q4=0;
    }
if($q5==NULL)
    {
        $q5=0;
    }
if($q6==NULL)
    {
        $q6=0;
    }
if($q7==NULL)
    {
        $q7=0;
    }
if($q8==NULL)
    {
        $q8=0;
    }
if($q9==NULL)
    {
        $q9=0;
    }
if($q10==NULL)
    {
        $q10=0;
    }
if($q11==NULL)
    {
        $q11=0;
    }
if($q12==NULL)
    {
        $q12=0;
    }
if($q13==NULL)
    {
        $q13=0;
    }
if($q14==NULL)
    {
        $q14=0;
    }

if($q15==NULL)
    {
        $q15=0;
    }
if($q16==NULL)
    {
        $q16=0;
    }

    $tot=$q1+$q2+$q3+$q4+$q5+$q6+$q7+$q8+$q9+$q10+$q11+$q12+$q13+$q14+$q15+$q16;
    
      $conn=mysqli_connect("localhost","root","","nba");
      $sql="insert into endsem_mark values('$id','$course','$n','$q1','$q2','$q3','$q4','$q5','$q6','$q7','$q8','$q9','$q10','$q11','$q12','$q13','$q14','$q15','$q16','$tot')";
      $res=mysqli_query($conn,$sql);
      if(!$res)
      {
        echo "Error: ".mysqli_error($conn);
      }
      else
      {
        //header("location: .php");
      }
      $sql11="Select * from endsem where staff_id='$id' and course_code='$course'";
      $res11 = mysqli_query($conn,$sql11);
      $a= mysqli_num_rows($res11);

$sum_co1=0;
$sum_co2=0;
$sum_co3=0;
$sum_co4=0;
$sum_co5=0;
$sum_co6=0;

if($a>0)
{
    while($row=mysqli_fetch_assoc($res11))
    {
        if($row['co1']==1)
        {
            if($row['qno']==1)
            {
                $sum_co1+=$q1;    
            }
            if($row['qno']==2)
            {
                $sum_co1+=$q2;    
            }
            if($row['qno']==3)
            {
                $sum_co1+=$q3;    
            }
            if($row['qno']==4)
            {
                $sum_co1+=$q4;    
            }
            if($row['qno']==5)
            {
                $sum_co1+=$q5;    
            }
            if($row['qno']==6)
            {
                $sum_co1+=$q6;    
            }
            if($row['qno']==7)
            {
                $sum_co1+=$q7;    
            }
            if($row['qno']==8)
            {
                $sum_co1+=$q8;    
            }
            if($row['qno']==9)
            {
                $sum_co1+=$q9;    
            }
            if($row['qno']==10)
            {
                $sum_co1+=$q10;    
            }
            if($row['qno']==11)
            {
                $sum_co1+=$q11;    
            }
            if($row['qno']==12)
            {
                $sum_co1+=$q12;    
            }
            if($row['qno']==13)
            {
                $sum_co1+=$q13;    
            }
            if($row['qno']==14)
            {
                $sum_co1+=$q14;    
            } 
            if($row['qno']==15)
            {
                $sum_co1+=$q15;    
            }

            if($row['qno']==16)
            {
                $sum_co1+=$q16;    
            }

        }
        if($row['co2']==1)
        {
            if($row['qno']==1)
            {
                $sum_co2+=$q1;    
            }
            if($row['qno']==2)
            {
                $sum_co2+=$q2;    
            }
            if($row['qno']==3)
            {
                $sum_co2+=$q3;    
            }
            if($row['qno']==4)
            {
                $sum_co2+=$q4;    
            }if($row['qno']==5)
            {
                $sum_co2+=$q5;    
            }if($row['qno']==6)
            {
                $sum_co2+=$q6;    
            }
            if($row['qno']==7)
            {
                $sum_co2+=$q7;    
            }
            if($row['qno']==8)
            {
                $sum_co2+=$q8;    
            }

            if($row['qno']==9)
            {
                $sum_co2+=$q9;    
            }
            if($row['qno']==10)
            {
                $sum_co2+=$q10;    
            }
            if($row['qno']==11)
            {
                $sum_co2+=$q11;    
            }
            if($row['qno']==12)
            {
                $sum_co2+=$q12;    
            }
            if($row['qno']==13)
            {
                $sum_co2+=$q13;    
            }
            if($row['qno']==14)
            {
                $sum_co2+=$q14;    
            }
            if($row['qno']==15)
            {
                $sum_co2+=$q15;    
            }
            if($row['qno']==16)
            {
                $sum_co2+=$q16;    
            }
        }
        if($row['co3']==1)
        {
            if($row['qno']==1)
            {
                $sum_co3+=$q1;    
            }
            if($row['qno']==2)
            {
                $sum_co3+=$q2;    
            }
            if($row['qno']==3)
            {
                $sum_co3+=$q3;    
            }
            if($row['qno']==4)
            {
                $sum_co3+=$q4;    
            }if($row['qno']==5)
            {
                $sum_co3+=$q5;    
            }if($row['qno']==6)
            {
                $sum_co3+=$q6;    
            }
            if($row['qno']==7)
            {
                $sum_co3+=$q7;    
            }
            if($row['qno']==8)
            {
                $sum_co3+=$q8;    
            }
            
            if($row['qno']==9)
            {
                $sum_co3+=$q9;    
            }
            if($row['qno']==10)
            {
                $sum_co3+=$q10;    
            }
            if($row['qno']==11)
            {
                $sum_co3+=$q11;    
            }
            if($row['qno']==12)
            {
                $sum_co3+=$q12;    
            }
            if($row['qno']==12)
            {
                $sum_co3+=$q12;    
            }
            if($row['qno']==13)
            {
                $sum_co3+=$q13;    
            }
            if($row['qno']==14)
            {
                $sum_co3+=$q14;    
            }
            if($row['qno']==15)
            {
                $sum_co3+=$q15;    
            }
            if($row['qno']==16)
            {
                $sum_co3+=$q16;    
            }
        }
        if($row['co4']==1)
        {
            if($row['qno']==1)
            {
                $sum_co4+=$q1;    
            }
            if($row['qno']==2)
            {
                $sum_co4+=$q2;    
            }
            if($row['qno']==3)
            {
                $sum_co4+=$q3;    
            }
            if($row['qno']==4)
            {
                $sum_co4+=$q4;    
            }if($row['qno']==5)
            {
                $sum_co4+=$q5;    
            }if($row['qno']==6)
            {
                $sum_co4+=$q6;    
            }
            if($row['qno']==7)
            {
                $sum_co4+=$q7;    
            }
            if($row['qno']==8)
            {
                $sum_co4+=$q8;    
            }
            if($row['qno']==9)
            {
                $sum_co4+=$q9;    
            }
            if($row['qno']==10)
            {
                $sum_co4+=$q10;    
            }
            if($row['qno']==11)
            {
                $sum_co4+=$q11;    
            }
            if($row['qno']==12)
            {
                $sum_co4+=$q12;    
            }if($row['qno']==13)
            {
                $sum_co4+=$q13;    
            }
            if($row['qno']==14)
            {
                $sum_co4+=$q14;    
            }
            if($row['qno']==15)
            {
                $sum_co4+=$q15;    
            }
            if($row['qno']==16)
            {
                $sum_co4+=$q16;    
            }
        }
        if($row['co5']==1)
        {
            if($row['qno']==1)
            {
                $sum_co5+=$q1;    
            }
            if($row['qno']==2)
            {
                $sum_co5+=$q2;    
            }
            if($row['qno']==3)
            {
                $sum_co5+=$q3;    
            }
            if($row['qno']==4)
            {
                $sum_co5+=$q4;    
            }if($row['qno']==5)
            {
                $sum_co5+=$q5;    
            }
            if($row['qno']==6)
            {
                $sum_co5+=$q6;    
            }
            if($row['qno']==7)
            {
                $sum_co5+=$q7;    
            }
            if($row['qno']==8)
            {
                $sum_co5+=$q8;    
            }
            if($row['qno']==9)
            {
                $sum_co5+=$q9;    
            }
            if($row['qno']==10)
            {
                $sum_co5+=$q10;    
            }
            if($row['qno']==11)
            {
                $sum_co5+=$q11;    
            }
            if($row['qno']==12)
            {
                $sum_co5+=$q12;    
            }
            if($row['qno']==13)
            {
                $sum_co5+=$q13;    
            }if($row['qno']==14)
            {
                $sum_co5+=$q14;    
            }
            if($row['qno']==15)
            {
                $sum_co5+=$q15;    
            }
            if($row['qno']==16)
            {
                $sum_co5+=$q16;    
            }
        }
        if($row['co6']==1)
        {            
            if($row['qno']==1)
            {
                $sum_co6+=$q1;    
            }
            if($row['qno']==2)
            {
                $sum_co6+=$q2;    
            }
            if($row['qno']==3)
            {
                $sum_co6+=$q3;    
            }
            if($row['qno']==4)
            {
                $sum_co6+=$q4;    
            }if($row['qno']==5)
            {
                $sum_co6+=$q5;    
            }if($row['qno']==6)
            {
                $sum_co6+=$q6;    
            }
            if($row['qno']==7)
            {
                $sum_co6+=$q7;    
            }
            if($row['qno']==8)
            {
                $sum_co6+=$q8;    
            }
            if($row['qno']==9)
            {
                $sum_co6+=$q9;    
            }
            if($row['qno']==10)
            {
                $sum_co6+=$q10;    
            }
            if($row['qno']==11)
            {
                $sum_co6+=$q11;    
            }
            if($row['qno']==12)
            {
                $sum_co6+=$q12;    
            }
            if($row['qno']==13)
            {
                $sum_co6+=$q13;    
            }
            if($row['qno']==14)
            {
                $sum_co6+=$q14;    
            }
            if($row['qno']==15)
            {
                $sum_co6+=$q15;    
            }
            if($row['qno']==16)
            {
                $sum_co6+=$q16;    
            }
        }
    }

}
$sql12="insert into endsemco values('$id','$course','$n','$sum_co1','$sum_co2','$sum_co3','$sum_co4','$sum_co5','$sum_co6');";
$res12 = mysqli_query($conn,$sql12);

header('Refresh:1; url=endsem_mark.php');
echo "<script type='text/javascript'>alert('Mark added');</script>";


}
?>

<br>
<div class="heading">END SEM MARKS</div>
        <br><br>
        <div class="form-center">
<form action="#" name="signup" method="POST" style="font-size:160%;background-color:white;border:2px solid black;width:45%;height:60%;border-radius:20px;box-shadow: 0px 0px 10px 1px #000;padding:10px 0px 10px 40px;font-family:Georgia, serif;
    font-weight:bold;">

<?php

$id=$_SESSION['username'];
$conn=mysqli_connect("localhost","root","","nba");
      
$sql="Select course_code from course_details where staff_id='$id'";
$q=mysqli_query($conn,$sql);

echo "<label for='course'>Course : </label>";
echo    "<select name='course' id='course' style='width:45%;font-size:110%;background-color:#dde6f0;'>";
    
while($row = mysqli_fetch_assoc($q)) 
{        
echo "<option value='".$row['course_code']."'>".$row['course_code']."</option>"; 
}
echo  "</select><br>";
?>
<br>

    Register No: <input type="number" name="rno" placeholder="Register No" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

    Q1 : <input type="number" id="q1" name="q1" step="0.1" onkeyup="myFunction()" placeholder="Q1" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

    Q2 : <input type="number" id="q2" name="q2" step="0.1" onkeyup="myFunction()" placeholder="Q2" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

    Q3 : <input type="number" id="q3" name="q3" step="0.1" onkeyup="myFunction()" placeholder="Q3" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

    Q4 : <input type="number" id="q4" name="q4" step="0.1" onkeyup="myFunction()" placeholder="Q4" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

    Q5 : <input type="number" id="q5" name="q5" step="0.1" onkeyup="myFunction()" placeholder="Q5" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

    Q6 : <input type="number" id="q6" name="q6" step="0.1" onkeyup="myFunction()" placeholder="Q6" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

    Q7 : <input type="number" id="q7" name="q7" step="0.1" onkeyup="myFunction()" placeholder="Q7" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

    Q8 : <input type="number" id="q8" name="q8" step="0.1" onkeyup="myFunction()" placeholder="Q8" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

  Q9 : <input type="number" id="q9" name="q9" step="0.1" onkeyup="myFunction()" placeholder="Q9" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

Q10: <input type="number" id="q10" name="q10" step="0.1" onkeyup="myFunction()" placeholder="Q10" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

Q11: <input type="number" id="q11" name="q11" step="0.1" onkeyup="myFunction()" placeholder="Q11" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

Q12: <input type="number" id="q12" name="q12" step="0.1" onkeyup="myFunction()" placeholder="Q12" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

Q13: <input type="number" id="q13" name="q13" step="0.1" onkeyup="myFunction()" placeholder="Q13" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

Q14: <input type="number" id="q14" name="q14" step="0.1" onkeyup="myFunction()" placeholder="Q14" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

Q15: <input type="number" id="q15" name="q15" step="0.1" onkeyup="myFunction()" placeholder="Q15" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

Q16: <input type="number" id="q16" name="q16" step="0.1" onkeyup="myFunction()" placeholder="Q16" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>

Total Mark: <input type="number" id="tot" name="tot" step="0.1" class="text" style="height:80%;width:45%;font-size:120%;background-color:#dde6f0;"><br><br>
  
  <input type="submit" value="SUBMIT" style="font-family:Georgia, serif;font-size:150%;font-weight:bold;width:85%;height:80%;color:white;margin:30px 2px 15px 5px;border-radius:20px;background-color:black;"><br>
</form>
</div>
<script>
    function myFunction() 
{
    if(document.getElementById("q1").value !== "")
  {
    a1 = parseFloat(document.getElementById("q1").value);
  }
  else
  {
      a1=0;
  }
  if(document.getElementById("q2").value !== "")
  {
    a2 = parseFloat(document.getElementById("q2").value);
  }
  else
  {
      a2=0;
  }
  if(document.getElementById("q3").value !== "")
  {
    a3 = parseFloat(document.getElementById("q3").value);
  }
  else
  {
      a3=0;
  }
  if(document.getElementById("q4").value !== "")
  {
    a4 = parseFloat(document.getElementById("q4").value);
  }
  else
  {
      a4=0;
  }
  if(document.getElementById("q5").value !== "")
  {
    a5 = parseFloat(document.getElementById("q5").value);
  }
  else
  {
      a5=0;
  }
  if(document.getElementById("q6").value !== "")
  {
    a6 = parseFloat(document.getElementById("q6").value);
  }
  else
  {
      a6=0;
  }
  if(document.getElementById("q7").value !== "")
  {
    a7 = parseFloat(document.getElementById("q7").value);
  }
  else
  {
      a7=0;
  }
  if(document.getElementById("q8").value !== "")
  {
    a8 = parseFloat(document.getElementById("q8").value);
  }
  else
  {
      a8=0;
  }
  if(document.getElementById("q9").value !== "")
  {
    a9 = parseFloat(document.getElementById("q9").value);
  }
  else
  {
      a9=0;
  }

if(document.getElementById("q10").value !== "")
  {
    a10 = parseFloat(document.getElementById("q10").value);
  }
  else
  {
      a10=0;
  }

if(document.getElementById("q11").value !== "")
  {
    a11 = parseFloat(document.getElementById("q11").value);
  }
  else
  {
      a11=0;
  }


if(document.getElementById("q12").value !== "")
  {
    a12 = parseFloat(document.getElementById("q12").value);
  }
  else
  {
      a12=0;
  }


if(document.getElementById("q13").value !== "")
  {
    a13 = parseFloat(document.getElementById("q13").value);
  }
  else
  {
      a13=0;
  }


if(document.getElementById("q14").value !== "")
  {
    a14 = parseFloat(document.getElementById("q14").value);
  }
  else
  {
      a14=0;
  }

if(document.getElementById("q15").value !== "")
  {
    a15 = parseFloat(document.getElementById("q15").value);
  }
  else
  {
      a15=0;
  }
if(document.getElementById("q16").value !== "")
  {
    a16 = parseFloat(document.getElementById("q16").value);
  }
  else
  {
      a16=0;
  }




  console.log(typeof a1);
  console.log(typeof a2);
  console.log(typeof a3);
  console.log(typeof a4);
  console.log(typeof a5);
  console.log(typeof a6);
  console.log(typeof a7);
  console.log(typeof a8);
  console.log(typeof a9);
  console.log(typeof a10);
  console.log(typeof a11);
  console.log(typeof a12);
  console.log(typeof a13);
  console.log(typeof a14);
  console.log(typeof a15);
  console.log(typeof a16);
  
  var result = a1+a2+a3+a4+a5+a6+a7+a8+a9+a10+a11+a12+a13+a14+a15+a16;
  document.getElementById("tot").value = result;
}
    </script>
<br><br>
<div class="logout"><a href="dashboard.php">&#9654 HOME</a><br></div>

        

</body>
</html>