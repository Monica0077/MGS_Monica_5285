<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="style.css">
<style>
body{
font-family:Georgia, serif;
    font-weight:bold;}
.logout
  {
    box-shadow: 0px 0px 18px 1px black;;
    padding: 20px;
    display: block;
    visibility: visible;
    text-decoration: none;
    text-align: center;
    color: white;
    float:left;
    margin-left: 550px;
    background-color: #006994;
    text-transform: uppercase;
    font-weight: bolder;
    font-size: 20px;
  }
</style>
 </head>

<body>
<br>
<div class="heading" style="font-family:Georgia, serif;">
    CO ATTAINTMENT BAR GRAPH
</div>
<hr style="background-color:black ; text-align: center; width: 40%; margin-top: -17px;">
<br><br>
<br><br><br><br><br>
<?php

session_start();

$s1=$_SESSION['e1'];
$s2=$_SESSION['e2'];
$s3=$_SESSION['e3'];
$s4=$_SESSION['e4'];
$s5=$_SESSION['e5'];
$s6=$_SESSION['e6'];

$dataPoints = array( 
	array("y" => $s1, "label" => "CO1" ),
	array("y" => $s2, "label" => "CO2" ),
	array("y" => $s3, "label" => "CO3" ),
	array("y" => $s4, "label" => "CO4" ),
	array("y" => $s5, "label" => "CO5" ),
	array("y" => $s6, "label" => "CO6" )
);

?>
<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2",
	title:{
		text: "END SEMESTER"
	},
	axisY: {
		title: "CO Attaintment Levels(1,2,3)"
	},
  axisX: {
    title: "Course Objective"
  },
	data: [{
		type: "column",
		yValueFormatString: "#,##0.##",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 40%; margin-left: 440px"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>                              
<br><br>
<div class="logout"><a href="dispcoatt.php">&#9654 HOME</a><br></div>
<br><br><br><br><br>
<button onclick="window.print()" class="logout" style="font-family:Georgia,serif;text-decoration:underline;" >&#9654 Print This Page</button>

</body>
</html>

