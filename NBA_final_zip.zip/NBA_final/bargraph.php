<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="style.css">
<style>
.logout
  {
    box-shadow: 0px 0px 18px 1px black;;
    padding: 20px;
    display: block;
    visibility: visible;
    text-decoration: none;
    text-align: center;
    color: white;
    float:left;
    margin-left: 550px;
    background-color: #006994;
    text-transform: uppercase;
    font-weight: bolder;
    font-size: 20px;
  }

body{
font-family:Georgia, serif;
    font-weight:bold;}
</style>
 </head>

<body>
<br>
<div class="heading" style="font-family:Georgia, serif;">
    CO ATTAINTMENT BAR GRAPH
</div>
<hr style="background-color:black ; text-align: center; width: 40%; margin-top: -17px;">
<br><br>
<br><br><br><br><br>
<?php

session_start();

$k1=$_SESSION['i1'];
$k2=$_SESSION['i2'];
$k3=$_SESSION['i3'];
$k4=$_SESSION['i4'];
$k5=$_SESSION['i5'];
$k6=$_SESSION['i6'];
 
$dataPoints = array( 
	array("y" => $k1, "label" => "CO1" ),
	array("y" => $k2, "label" => "CO2" ),
	array("y" => $k3, "label" => "CO3" ),
	array("y" => $k4, "label" => "CO4" ),
	array("y" => $k5, "label" => "CO5" ),
	array("y" => $k6, "label" => "CO6" )
);

?>
<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function() {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2",
	title:{
		text: "INTERNAL ASSESSMENT"
	},
	axisY: {
		title: "CO Attaintment Levels(1,2,3)"
	},
  axisX: {
    title: "Course Objective"
  },
	data: [{
		type: "column",
		yValueFormatString: "#,##0.##",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 40%; margin-left: 440px"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>                              
<br><br>
<div class="logout"><a href="dispcoatt.php">&#9654 HOME</a><br></div>
<br><br><br><br><br>
<button onclick="window.print()" class="logout" style="font-family:Georgia,serif;text-decoration:underline;" >&#9654 Print This Page</button>
</body>
</html>

