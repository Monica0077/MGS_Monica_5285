<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="style.css">
  <style>
 body{
font-family:Georgia, serif;
    font-weight:bold;}   
.logout
  {
    box-shadow: 0px 0px 18px 1px black;;
    padding: 20px;
    display: block;
    visibility: visible;
    text-decoration: none;
    text-align: center;
    color: white;
    float:left;
    margin-left: 650px;
    background-color: #006994;
    text-transform: uppercase;
    font-weight: bolder;
    font-size: 20px;
  }
</style>
 </head>
<body>
<body>
<br>
<div class="heading" style="font-family:Georgia, serif;">
    VIEW CO CALCULATION
</div>
<hr style="background-color:black ; text-align: center; width: 40%; margin-top: -17px;">
<br>
<div class="box3">
<br><br><br>
<div class="a2"><br><a href="cocalc_assess1.php">&#9654 ASSESSMENT 1</a></div>
<div class="a3"><br><a href="cocalc_assess2.php">&#9654 ASSESSMENT 2</a></div>
<div class="a3"><br><a href="cocalc_endsem.php">&#9654 END SEM</a></div>
<br>
</div>
<br>
<br><br>
<div class="logout"><a href="dashboard.php">&#9654 HOME</a><br></div>
</body>
</html>

